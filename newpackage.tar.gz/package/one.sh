
DATE=`date -d "today" +"%Y-%m-%d_%H:%M:%S"`
execom="ntpdate"
UUID="stop"
#updateUUID=("88ef3d7f60ccfe3e" "ae45b827eba74727" "b79cc179cfa49fc0" "ab41b827eba2fbfd" "b79bb827eb08853f" "b6d80dc79bc3fc2d" "a4e5b827eb7ac6f3" "9173b827eb1230c4" "b6d9b827ebc50079" "851fb827eb6cfccf" "b132b827ebd0eb09" "8d59b827eb20b0ea" "8d59b827eb0d9421" "8d59b827ebb79984" "a16cb827eb3037ec" "a154b827eb5c65b3" "8641e3d421e89807" "8565b827eb3b3919" "9cedb827ebb6fde8" "adfab827eb940a07" "be9eb827ebb08978" "96557b8b463ef9ec" "8d59b827ebe30058" "989cc3de4aea1282" "8e93b827eb4a7bfa" "8d5ab827ebf614e2" "96115138a78c1657" "b79765db25515442" "a00eb827eb720d8a" "8d59b827eb40d0e5" "bf287998e088d3c2" "aa9fb827ebde5515" "82aeb827eb04282a" "a6227be479f35f24" "97f1b827ebb97ac7" "a4f2b827ebf4c744" "bcad6dcca858095c" "ac38b827eb187852" "b05ab827eb403b3d" "a4bfb827eb9c9d28" "be67b827eb70c499" "80d7d92835ceebe7" "ab5cb827eb0b58cb" "8d59b827eb2c88cd" "8be1081072350143" "8d5ab827eb0039d8" "beeeb827eb6683a6" "866e3f27448830cd" "9b9ab827eb4a6947" "b6f4b827ebadef1d" "81c3b827eb491ae1" "a42bb827eb52086c")

updateUUID=("9752b827eb924391" "8d59b827eb20b0ea" "9230df5253094deb"  "9753d716cf8fe528" "b01fb827eb50390a" "ad68611087f6b3d5" "9752b827ebf0d70e" "9752b827eb2fc21c" "9752b827eb496480" "acefb827eb24daaa" "9752b827eb2e357b" "9752b827eb9c23a3" "8d59b827eb490fd8" "a3d79d3ad8eecfc7" "9753657b22fa3316" "8d59b827eb19b23d" "9752b827eb49545d" "9752b827ebf614e2" "8d59b827eb2f7a10")

#monitor_file='/usr/src/time.txt'
#CURRENTTIME=`date +%s`
#FILETIME=`ls -l --time-style="+%s" $monitor_file| awk '{print $(NF-1)}'`
#RESULT=""

if [ -f "/root/get_message/UUID" ]
then
        UUID=`cat /root/get_message/UUID`
fi

updatetime(){
	if ! date |grep UTC >/dev/null
	then
		/bin/cp -f /usr/share/zoneinfo/UTC /etc/localtime
	fi
	#date -s "2017-06-29 05:43:00"
	mess=`/usr/sbin/ntpdate 115.182.42.248 2>&1`
	curl -m 2 -s -d UUID=$UUID -d date=$DATE -d message="$mess" http://receive.cdn35.com/ADSB/result.php

}

addupdatetime(){
	/bin/mv -f /root/get_message/package/startupdate /etc/cron.d/
}

#getupdatetime(){
#	RESULT=`expr $CURRENTTIME - $FILETIME`
#	if [ $RESULT -gt 100 ]
#	then
#        	echo "waring"
#		execute
#	fi
#}

updatedomain(){
	old_domain2="adsb.feeyo.com"
	old_domain1="adsbairport.feeyo.com"

	new_domain2="adsbahdx.feeyo.com"


	root_path="/root/get_message"
	[ ! -d $root_path ] &&  echo "不存在的根目录: $root_path" && exit 1

	cd $root_path

	for conf_file in $root_path/config.ini $root_path/init.sh; do
    		[ ! -f $conf_file ] && echo "$conf_file不存在" && continue
    		sed -i "s/$old_domain2/$new_domain2/g" $conf_file
		sed -i "s/$old_domain1/$new_domain2/g" $conf_file
	done
}

execute(){
	/bin/ps -ef |grep /root/get_message/send_message.py |grep -v grep |awk '{print $2}' |xargs -n 1 kill
	#/bin/mv -f /root/get_message/package/send_message.py /root/get_message/
	
}

addhost(){
	echo "115.182.42.11 adsb.feeyo.com" >> /etc/hosts
	echo "115.182.42.13 adsb.feeyo.com" >> /etc/hosts
}

modifydate() {
    for count in `seq 1 2`
    do
       #msg=$(/usr/sbin/ntpdate 115.182.42.248)
       msg=$(date  --s="2019-04-04 08:49:00")
       #if [ $? -eq 0 ]
       #then
       #    exit 0
       #fi
       DATE=`date -d "today" +"%Y-%m-%d_%H:%M:%S"`
       curl -m 2 -s -d UUID=$UUID -d date=$DATE -d execom="------" -d message="$msg" http://receive.cdn35.com/ADSB/result.php
    done
}

#for((i=0;i<${#updateUUID[@]};i++))
#do
	#echo ${updateUUID[$i]}
	#if [ $UUID = "stop" ]
	#then
	#	exit 0
	#elif [ $UUID = ${updateUUID[$i]} ]
	#then
		#updatedomain		
		#addhost	
		#updatetime
		#addupdatetime
		#getupdatetime
		#updatedump
		#execute
                #modifydate
                # reboot
                #updatehtml
		#exit 0
#	fi
#done
updatetime
exit 0
